from django.contrib import admin
from .models import Rutina

@admin.register(Rutina)
class RutinaAdmin(admin.ModelAdmin):
    list_display = ('dia', 'descripcion', 'created_at', 'updated_at')
    list_filter = ('dia',)
    search_fields = ('descripcion',)
