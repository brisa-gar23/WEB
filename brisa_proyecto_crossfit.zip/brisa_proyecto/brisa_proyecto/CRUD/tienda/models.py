from django.db import models
from django.contrib.auth.models import User

class Producto(models.Model):
    titulo = models.CharField(max_length=50, blank=False, verbose_name='Titulo')
    fecha = models.DateField(verbose_name='Fecha de inicio')  
    descripcion = models.CharField(max_length=200, blank=False, verbose_name='Descripcion')

class Rutina(models.Model):
    dia = models.CharField(max_length=20, choices=[
        ('lunes', 'Lunes'),
        ('martes', 'Martes'),
        ('miercoles', 'Miércoles'),
        ('jueves', 'Jueves'),
        ('viernes', 'Viernes'),
    ])
    descripcion = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Rutina del {self.dia.capitalize()}"
