from django.shortcuts import render, redirect, get_object_or_404
from tienda.models import Producto
from django.contrib import messages
from django.contrib.auth.decorators import login_required  # Decorador para proteger vistas
from django.contrib.auth.models import User  # Modelo para usuarios
from django.contrib.auth.forms import UserCreationForm

from django.contrib.auth.decorators import user_passes_test
from .models import Rutina
from .forms import RutinaForm

from tienda.models import Rutina



# Página principal
def home(request):
    return render(request, "principal.html")


def registro(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Te has registrado correctamente.")
            return redirect('login')  # Redirige al inicio de sesión
        else:
            messages.error(request, "Por favor, corrige los errores en el formulario.")
    else:
        form = UserCreationForm()
    
    return render(request, 'registro.html', {'form': form})



# Listar productos
@login_required
def consultar(request):
    productos = Producto.objects.all()
    return render(request, "producto.html", {'productos': productos})


# Guardar un nuevo producto
@login_required
def guardar(request):
    if request.method == 'POST':
        titulo = request.POST.get("titulo", "").strip()
        fecha = request.POST.get("fecha", "").strip()
        descripcion = request.POST.get("descripcion", "").strip()

        # Validar campos
        if not titulo or not fecha or not descripcion:
            messages.error(request, "Todos los campos son obligatorios.")
            return redirect('consultar')

        # Guardar producto
        try:
            p = Producto(titulo=titulo, fecha=fecha, descripcion=descripcion)
            p.save()
            messages.success(request, 'Actividad agregada correctamente.')
        except Exception as e:
            messages.error(request, f"Error al guardar la actividad: {str(e)}")
        return redirect('consultar')
    return redirect('consultar')


# Eliminar producto
@login_required
def eliminar(request, id):
    try:
        producto = Producto.objects.get(pk=id)
        producto.delete()
        messages.success(request, 'Actividad eliminada correctamente.')
    except Producto.DoesNotExist:
        messages.error(request, 'El producto no existe.')
    except Exception as e:
        messages.error(request, f"Error al eliminar la actividad: {str(e)}")
    return redirect('consultar')


# Mostrar detalles de un producto para editar
@login_required
def detalle(request, id):
    try:
        producto = get_object_or_404(Producto, pk=id)
        return render(request, "productoEditar.html", {'producto': producto})
    except Exception as e:
        messages.error(request, f"Error al cargar los detalles del producto: {str(e)}")
        return redirect('consultar')


# Editar un producto existente
@login_required
def editar(request, id):
    producto = get_object_or_404(Producto, pk=id)

    if request.method == 'POST':
        titulo = request.POST.get("titulo", "").strip()
        fecha = request.POST.get("fecha", "").strip()
        descripcion = request.POST.get("descripcion", "").strip()

        # Validar campos
        if not titulo or not fecha or not descripcion:
            messages.error(request, "Todos los campos son obligatorios.")
            return redirect('consultar')

        # Actualizar producto
        try:
            producto.titulo = titulo
            producto.fecha = fecha
            producto.descripcion = descripcion
            producto.save()
            messages.success(request, 'Actividad actualizada correctamente.')
        except Exception as e:
            messages.error(request, f"Error al actualizar la actividad: {str(e)}")
        return redirect('consultar')

    return render(request, "productoEditar.html", {'producto': producto})


@login_required
def dia(request, dia_nombre):
    # Diccionario para asociar los días de la semana con sus plantillas
    dias_plantillas = {
        "lunes": "dias/lunes.html",
        "martes": "dias/martes.html",
        "miercoles": "dias/miercoles.html",
        "jueves": "dias/jueves.html",
        "viernes": "dias/viernes.html",
    }

    # Verificar que el día exista en el diccionario
    if dia_nombre in dias_plantillas:
        rutinas = Rutina.objects.filter(dia=dia_nombre)  # Obtener rutinas del día
        return render(request, dias_plantillas[dia_nombre], {'rutinas': rutinas})
    else:
        # En caso de que el día no exista, redirige al home
        messages.error(request, "El día solicitado no existe.")
        return redirect('inicio')
    




##################################################
# Verificar si el usuario es administrador
def es_admin(user):
    return user.is_superuser

@login_required
@user_passes_test(es_admin)
def listar_rutinas(request):
    rutinas = Rutina.objects.all()
    return render(request, 'rutinas/listar.html', {'rutinas': rutinas})

@login_required
@user_passes_test(es_admin)
def crear_rutina(request):
    if request.method == 'POST':
        form = RutinaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Rutina creada correctamente.')
            return redirect('listar_rutinas')
    else:
        form = RutinaForm()
    return render(request, 'rutinas/crear.html', {'form': form})

@login_required
@user_passes_test(es_admin)
def editar_rutina(request, pk):
    rutina = get_object_or_404(Rutina, pk=pk)
    if request.method == 'POST':
        form = RutinaForm(request.POST, instance=rutina)
        if form.is_valid():
            form.save()
            messages.success(request, 'Rutina actualizada correctamente.')
            return redirect('listar_rutinas')
    else:
        form = RutinaForm(instance=rutina)
    return render(request, 'rutinas/editar.html', {'form': form})

@login_required
@user_passes_test(es_admin)
def eliminar_rutina(request, pk):
    rutina = get_object_or_404(Rutina, pk=pk)
    if request.method == 'POST':
        rutina.delete()
        messages.success(request, 'Rutina eliminada correctamente.')
        return redirect('listar_rutinas')
    return render(request, 'rutinas/eliminar.html', {'rutina': rutina})

@login_required
def detalle_rutina(request, pk):
    rutina = get_object_or_404(Rutina, pk=pk)
    return render(request, 'rutinas/detalle.html', {'rutina': rutina})
