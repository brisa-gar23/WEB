from django import forms
from .models import Rutina

class RutinaForm(forms.ModelForm):
    class Meta:
        model = Rutina
        fields = ['dia', 'descripcion']
