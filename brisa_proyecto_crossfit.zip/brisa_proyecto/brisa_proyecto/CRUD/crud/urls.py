"""
URL configuration for crud project.

The urlpatterns list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from tienda import views
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('admin/', admin.site.urls),

    # Página de inicio
    path('', views.home, name='inicio'),

    # Autenticación de usuarios
    path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),  # Página de inicio de sesión
    path('logout/', auth_views.LogoutView.as_view(next_page='inicio'), name='logout'),  # Cerrar sesión
    path('registro/', views.registro, name='registro'),  # Registro de usuarios

    # CRUD de productos (protegido por autenticación)
    path('productos/', views.consultar, name='consultar'),  # Listar productos
    path('productos/guardar/', views.guardar, name='guardar'),  # Guardar producto
    path('productos/eliminar/<int:id>/', views.eliminar, name='eliminar'),  # Eliminar producto
    path('productos/detalle/<int:id>/', views.detalle, name='detalle'),  # Detalle de producto
    path('productos/editar/<int:id>/', views.editar, name='editar_producto'),  # Editar producto

    # Rutas específicas para los días de la semana (protegidas por autenticación)
    path('lunes/', views.dia, {'dia_nombre': 'lunes'}, name='lunes'),
    path('martes/', views.dia, {'dia_nombre': 'martes'}, name='martes'),
    path('miercoles/', views.dia, {'dia_nombre': 'miercoles'}, name='miercoles'),
    path('jueves/', views.dia, {'dia_nombre': 'jueves'}, name='jueves'),
    path('viernes/', views.dia, {'dia_nombre': 'viernes'}, name='viernes'),
    
    path('registro/', views.registro, name='registro'),  # Ruta para el registro
    path('', views.home, name='inicio'),  # Página de inicio
    path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),  # Login
    path('logout/', auth_views.LogoutView.as_view(next_page='principal'), name='logout'), # Logout

     path('rutinas/', views.listar_rutinas, name='listar_rutinas'),
    path('rutinas/crear/', views.crear_rutina, name='crear_rutina'),
    path('rutinas/editar/<int:pk>/', views.editar_rutina, name='editar_rutina'),
    path('rutinas/eliminar/<int:pk>/', views.eliminar_rutina, name='eliminar_rutina'),
    path('rutinas/detalle/<int:pk>/', views.detalle_rutina, name='detalle_rutina'),
]

